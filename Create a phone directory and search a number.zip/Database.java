public class Database {

   private Contact[] contacts = new Contact[80];
   private int index = 0;

   public Contact saveContact(Contact contact) {
      if (index % 80 == 0) {
         expandContactsArray();
      }
   
   
      if (!contactExist(contact)) {
         contacts[index] = contact;
         index +=1;
         System.out.println("New contact added!");
         return contact;
      } else {
         System.out.println("This contact already exists!");
         return null;
      }
   }

   public void deleteContact(Contact contact) {
   
      for (int i = 0; i < index; i++) {
         if (contacts[i] == contact) {
            contacts[i] = null;
         }
      }
   }

   public boolean contactExist(Contact contact) { 
      for (int i = 0; i < index; i++) {
         if (
                contacts[i].getFirstName().equals(contact.getFirstName())
                &&
                contacts[i].getLastName().equals(contact.getLastName())
                &&
                contacts[i].getPhoneNumber().equals(contact.getPhoneNumber())
         ) {
            System.out.println("Kontakti im i " + i + "-te eshte po ky qe doni te shtoni");
            return true;
         }
      }
      return false;
   }

   public Contact[] searchContact(String query) {
   
      Contact[] searchResults = new Contact[this.contacts.length];
      int innerIndex = 0;
      for (int i = 0; i < index; i++) {
         if ( contacts[i].getFirstName().contains(query)
              ||
              contacts[i].getLastName().contains(query)
              ||
              contacts[i].getPhoneNumber().contains(query)
         ) {
           
            searchResults[innerIndex] = contacts[i];
            innerIndex+=1;
         }
      }
      
      Contact[] returnResult = refinedSearchContact(searchResults);
      printSearchResults(returnResult, query);
      return returnResult;
   }

  
   public Contact[] refinedSearchContact(Contact[] results) {
      int countNullFields = 0;
      for (int i = 0; i < results.length; i++) {
         if (results[i] == null) {
            countNullFields+=1;
         }
      }
   
      int innerIndex = 0;
      Contact[] resultsWithoutNulls = new Contact[results.length-countNullFields];
     
      for (int i = 0; i < results.length; i++) {
        
         if (results[i] != null) {
            resultsWithoutNulls[innerIndex] = results[i];
            innerIndex += 1;
         }
      }
      return resultsWithoutNulls;
   }

   public void listContacts() {
      System.out.println("All my contacts");
      System.out.println("---------------");
      System.out.println();
      for (int i = 0; i < index; i++) {
         System.out.println(contacts[i].toString());
         System.out.println("-------------------------------");
      }
   }

  
   public void printSearchResults(Contact[] searchContact, String query) {
      System.out.println("Result of the search: " + query);
      System.out.println("----------------------------");
      System.out.println();
      for (int i = 0; i < searchContact.length; i++) {
         System.out.println(searchContact[i]);
         System.out.println();
      }
   }


   public void expandContactsArray() {
      Contact[] temp = new Contact[index + 80];
      for (int i = 0; i < index; i++) {
         temp[i] = this.contacts[i];
      }
    
      this.contacts = temp;
   }
}
