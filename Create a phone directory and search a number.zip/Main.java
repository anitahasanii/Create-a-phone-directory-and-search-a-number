public class Main {
   public static void main(String[] args) {
   
      Contact firstContact = new Contact("Adele", "Blau", "+38344111111");
      Contact secondContact = new Contact("Adelee", "Bleu", "+38344111121");
      Contact thirdContact = new Contact("Adeleeee", "Bra", "+38344111171");
      Contact fourthContact = new Contact("Adelaida", "Jackson", "+38344111131");
      Contact fifthContact = new Contact("Bob", "Binson", "+38344111119");
      Contact sixthContact = new Contact("Ina", "Crown", "+38344111118");
   
      Database database = new Database();
      
      database.saveContact(firstContact);
      database.saveContact(secondContact);
      database.saveContact(thirdContact);
      database.saveContact(fourthContact);
      database.saveContact(fifthContact);
      database.saveContact(sixthContact);
   
      database.listContacts();
   
      System.out.println();
   
      database.searchContact("3834411111");
   }
}
